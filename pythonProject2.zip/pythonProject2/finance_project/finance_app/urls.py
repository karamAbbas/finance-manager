from django.urls import path
from .views import TransactionListView, TransactionCreateView, TransactionUpdateView, TransactionDeleteView

urlpatterns = [
    path('', TransactionListView.as_view(), name='transaction_list'),
    path('add/', TransactionCreateView.as_view(), name='transaction_add'),
    path('edit/<int:pk>/', TransactionUpdateView.as_view(), name='transaction_edit'),
    path('delete/<int:pk>/', TransactionDeleteView.as_view(), name='transaction_delete'),
]
